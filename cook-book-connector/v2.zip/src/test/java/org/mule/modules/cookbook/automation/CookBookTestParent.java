package org.mule.modules.cookbook.automation;

import org.mule.modules.tests.ConnectorTestCase;

public class CookBookTestParent extends ConnectorTestCase {

}
