package org.mule.modules.cookbook.automation;

public interface SmokeTests {

}
