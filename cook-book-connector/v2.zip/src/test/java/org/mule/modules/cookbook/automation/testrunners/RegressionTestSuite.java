package org.mule.modules.cookbook.automation.testrunners;

import org.junit.runner.RunWith;
import org.mule.modules.cookbook.automation.RegressionTests;

@RunWith(org.junit.experimental.categories.Categories.class)
@org.junit.experimental.categories.Categories.IncludeCategory(RegressionTests.class)
@org.junit.runners.Suite.SuiteClasses({

})
public class RegressionTestSuite {

}
